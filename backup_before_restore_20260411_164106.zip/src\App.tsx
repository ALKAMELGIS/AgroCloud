import { Suspense, lazy, useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import HeaderBar from './components/HeaderBar'
import NavMenu from './components/NavMenu'

const Home = lazy(() => import('./pages/Home'))
const Login = lazy(() => import('./pages/Login'))
const SatelliteIntelligence = lazy(() => import('./pages/satellite/SatelliteIntelligence'))
const SatelliteMultidimensional = lazy(() => import('./pages/satellite/Multidimensional'))
const DataEntryFertigationRecords = lazy(() => import('./pages/data-entry/FertigationRecords'))
const DataEntryIrrigation = lazy(() => import('./pages/data-entry/Irrigation'))
const DataEntryHarvest = lazy(() => import('./pages/data-entry/Harvest'))
const DataEntryQHIS = lazy(() => import('./pages/data-entry/QHIS'))
const DataEntryECPH = lazy(() => import('./pages/data-entry/EC'))
const AccountProfile = lazy(() => import('./pages/account/Profile'))
const AccountSettings = lazy(() => import('./pages/account/Settings'))
const AdminUsers = lazy(() => import('./pages/admin/Users'))
const DashboardOverview = lazy(() => import('./pages/dashboards/Overview'))
const DashboardPlantAI = lazy(() => import('./pages/dashboards/PlantAI'))
const DashboardAiChatbot = lazy(() => import('./pages/dashboards/AiChatbot'))
const DashboardModel = lazy(() => import('./pages/dashboards/Model'))

type AuthUser = {
  id: number
  name: string
  email: string
  role: string
}

function AppShell() {
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => {
    try {
      const stored = localStorage.getItem('currentUser')
      if (!stored) return null
      const parsed = JSON.parse(stored) as unknown
      if (parsed && typeof parsed === 'object' && 'email' in parsed) return parsed as AuthUser
      return null
    } catch {
      return null
    }
  })
  const location = useLocation()

  useEffect(() => {
    const syncFromStorage = () => {
      try {
        const stored = localStorage.getItem('currentUser')
        if (!stored) {
          setCurrentUser(null)
          return
        }
        const parsed = JSON.parse(stored) as unknown
        if (parsed && typeof parsed === 'object' && 'email' in parsed) {
          setCurrentUser(parsed as AuthUser)
        } else {
          setCurrentUser(null)
        }
      } catch {
        setCurrentUser(null)
      }
    }

    syncFromStorage()
    window.addEventListener('storage', syncFromStorage)
    return () => window.removeEventListener('storage', syncFromStorage)
  }, [])

  const handleLogin = (user: AuthUser) => {
    setCurrentUser(user)
  }

  const handleLogout = () => {
    localStorage.removeItem('currentUser')
    setCurrentUser(null)
  }

  const isOnLogin = location.pathname === '/login'

  if (!currentUser && !isOnLogin) {
    return <Navigate to="/login" replace />
  }

  if (currentUser && isOnLogin) {
    return <Navigate to="/" replace />
  }

  return (
    <>
      {currentUser && <HeaderBar />}
      <div className="layout">
        {currentUser && (
          <aside>
            <NavMenu onLogout={handleLogout} />
          </aside>
        )}
        <main className="content">
          <Suspense fallback={<div style={{ padding: 12 }}>Loading</div>}>
            <Routes>
              <Route path="/login" element={<Login onLogin={handleLogin} />} />
              <Route path="/" element={<Home />} />
              <Route path="/satellite" element={<Navigate to="/satellite/indices" replace />} />
              <Route path="/data/fertigation" element={<Navigate to="/data/fertigation-records" replace />} />
              <Route path="/data/fertigation-records" element={<DataEntryFertigationRecords />} />
              <Route path="/data/irrigation" element={<DataEntryIrrigation />} />
              <Route path="/data/harvest" element={<DataEntryHarvest />} />
              <Route path="/data/qhis" element={<DataEntryQHIS />} />
              <Route path="/data/production" element={<DataEntryHarvest />} />
              <Route path="/data/ec-ph" element={<DataEntryECPH />} />
              <Route path="/satellite/indices" element={<SatelliteIntelligence />} />
              <Route path="/satellite/multidimensional" element={<SatelliteMultidimensional />} />
              <Route path="/dashboards/overview" element={<DashboardOverview />} />
              <Route path="/dashboards/plant-ai" element={<DashboardPlantAI />} />
              <Route path="/dashboards/ai-chatbot" element={<DashboardAiChatbot />} />
              <Route path="/dashboards/model" element={<DashboardModel />} />
              <Route path="/account/profile" element={<AccountProfile />} />
              <Route path="/account/settings" element={<AccountSettings />} />
              <Route path="/admin/users" element={<AdminUsers />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Suspense>
        </main>
      </div>
    </>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppShell />
    </BrowserRouter>
  )
}
