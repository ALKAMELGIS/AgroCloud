import{j as e}from"./index-CqhRypAj.js";function s(){return e.jsx("div",{className:"page"})}export{s as default};
