import { MapContainer, TileLayer, ZoomControl, ScaleControl } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'

type Props = { center?: [number, number]; zoom?: number; mapboxToken?: string }

export default function MapView({ center = [25, 55], zoom = 10, mapboxToken }: Props) {
  const useMapbox = Boolean(mapboxToken)
  const url = useMapbox
    ? `https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/{z}/{x}/{y}?access_token=${mapboxToken}`
    : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
  const attribution = useMapbox
    ? '© Mapbox © OpenStreetMap'
    : '© OpenStreetMap contributors'
  return (
    <MapContainer center={center} zoom={zoom} style={{ height: '100%', width: '100%' }} zoomControl={false}>
      <TileLayer url={url} attribution={attribution} />
      <ZoomControl position="topright" />
      <ScaleControl position="bottomleft" />
    </MapContainer>
  )
}
