import { useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

import { DataSourceFieldsPanel, type DataSourceFormState } from './components/datasourcefieldspanel'
import { canManageDataSourceSettings } from '../../lib/auth'

import './EC.css'

export default function Harvest() {
  const navigate = useNavigate()
  const location = useLocation()
  const isProduction = location.pathname === '/data/production'
  const title = isProduction ? 'Production Tracking' : 'Harvest Logging'
  const icon = isProduction ? 'fa-boxes-stacked' : 'fa-tractor'

  const [, setDataSourceState] = useState<DataSourceFormState>({ sourceIds: [], selectedFieldsBySource: {}, valuesBySource: {} })
  const [isOpeningSettings, setIsOpeningSettings] = useState(false)

  const canManageSettings = useMemo(() => canManageDataSourceSettings(), [])
  const formKey = isProduction ? 'Production' : 'Harvest'

  return (
    <div className="ec-page">
      <div className="ec-container ec-animate-in">
        <div className="ec-header">
          <div className="ec-title">
            <i className={`fa-solid ${icon}`}></i>
            <div>
              {title}
              <div className="ec-section-subtitle">Operations form (Master Data context)</div>
            </div>
          </div>
        </div>

        <div className="ec-card">
          <div className="ec-card-header">
            <div>
              <div className="ec-card-title">
                <i className="fa-solid fa-circle-info" style={{ color: 'var(--ec-primary)' }}></i>
                Basic Information
              </div>
              <div className="ec-card-subtitle-small">Configured in Settings (Manager and Admin only)</div>
            </div>
            {canManageSettings ? (
              <div className="ec-card-header-actions">
                <button
                  type="button"
                  className="ec-icon-btn"
                  aria-label="Open data source settings"
                  title="Settings"
                  disabled={isOpeningSettings}
                  onClick={() => {
                    setIsOpeningSettings(true)
                    navigate(`/master/workflow-settings?form=${isProduction ? 'Production' : 'Harvest'}`)
                  }}
                >
                  <i className={isOpeningSettings ? 'fa-solid fa-spinner fa-spin' : 'fa-solid fa-gear'}></i>
                </button>
              </div>
            ) : null}
          </div>
          <div className="ec-card-body">
            <DataSourceFieldsPanel
              formKey={formKey}
              mode="fill"
              variant="embedded"
              onChange={setDataSourceState}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
