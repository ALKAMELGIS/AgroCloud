import { useEffect, useMemo, useState } from 'react'

type FieldConfig = { name: string; enabled: boolean }
type FormBinding = {
  sourceId?: string
  sourceIds?: string[]
  fieldConfigsBySource?: Record<string, FieldConfig[]>
  selectedFieldsBySource?: Record<string, string[]>
}
type FormBindings = Record<string, FormBinding>

export type DataSourceFormState = {
  sourceIds: string[]
  selectedFieldsBySource: Record<string, string[]>
  valuesBySource: Record<string, Record<string, string>>
}

type Props = {
  formKey: string
  mode: 'settings' | 'fill'
  variant?: 'embedded'
  onChange?: (state: DataSourceFormState) => void
}

const STORAGE_KEY = 'form_data_source_bindings_v1'

const readJson = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

const writeJson = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
  }
}

const normalizeIds = (input: unknown): string[] =>
  Array.isArray(input) ? input.filter(v => typeof v === 'string').map(v => v.trim()).filter(Boolean) : []

const normalizeEnabledBySource = (binding: FormBinding | undefined): { sourceIds: string[]; enabledBySource: Record<string, string[]> } => {
  const sourceIds = normalizeIds(binding?.sourceIds)
  const legacy = typeof binding?.sourceId === 'string' ? binding.sourceId.trim() : ''
  const ids = sourceIds.length ? Array.from(new Set(sourceIds)) : legacy ? [legacy] : []
  const enabledBySource: Record<string, string[]> = {}
  for (const id of ids) {
    const configs = binding?.fieldConfigsBySource?.[id]
    if (Array.isArray(configs)) {
      enabledBySource[id] = configs.filter(c => c && c.enabled).map(c => c.name).filter(Boolean)
      continue
    }
    const legacySelected = binding?.selectedFieldsBySource?.[id]
    enabledBySource[id] = Array.isArray(legacySelected) ? legacySelected.filter(Boolean) : []
  }
  return { sourceIds: ids, enabledBySource }
}

const parseCsv = (value: string): string[] =>
  value
    .split(',')
    .map(v => v.trim())
    .filter(Boolean)
    .slice(0, 200)

export function DataSourceFieldsPanel({ formKey, mode, onChange }: Props) {
  const [isOpen, setIsOpen] = useState(mode !== 'fill')
  const [draftSourceIds, setDraftSourceIds] = useState<string[]>([])
  const [draftEnabledCsvBySource, setDraftEnabledCsvBySource] = useState<Record<string, string>>({})

  const bindings = useMemo(() => readJson<FormBindings>(STORAGE_KEY, {}), [formKey])
  const enabledInfo = useMemo(() => normalizeEnabledBySource(bindings[formKey]), [bindings, formKey])

  const [valuesBySource, setValuesBySource] = useState<Record<string, Record<string, string>>>({})

  useEffect(() => {
    if (mode === 'fill') {
      const nextValues: Record<string, Record<string, string>> = {}
      for (const sourceId of enabledInfo.sourceIds) {
        nextValues[sourceId] = valuesBySource[sourceId] ?? {}
      }
      setValuesBySource(nextValues)
      const state: DataSourceFormState = {
        sourceIds: enabledInfo.sourceIds,
        selectedFieldsBySource: enabledInfo.enabledBySource,
        valuesBySource: nextValues,
      }
      onChange?.(state)
    } else {
      const ids = enabledInfo.sourceIds.length ? enabledInfo.sourceIds : ['']
      setDraftSourceIds(ids)
      const nextCsv: Record<string, string> = {}
      for (const id of ids) {
        const enabled = enabledInfo.enabledBySource[id] ?? []
        nextCsv[id] = enabled.join(', ')
      }
      setDraftEnabledCsvBySource(nextCsv)
    }
  }, [mode, formKey])

  const saveSettings = () => {
    const sourceIds = draftSourceIds.map(v => v.trim()).filter(Boolean)
    const fieldConfigsBySource: Record<string, FieldConfig[]> = {}
    const selectedFieldsBySource: Record<string, string[]> = {}
    for (const id of sourceIds) {
      const enabled = parseCsv(draftEnabledCsvBySource[id] ?? '')
      selectedFieldsBySource[id] = enabled
      fieldConfigsBySource[id] = enabled.map(name => ({ name, enabled: true }))
    }
    const nextBindings: FormBindings = { ...bindings }
    nextBindings[formKey] = { sourceIds, selectedFieldsBySource, fieldConfigsBySource }
    writeJson(STORAGE_KEY, nextBindings)
    setIsOpen(false)
  }

  if (mode === 'settings') {
    return (
      <div style={{ border: '1px solid #e2e8f0', borderRadius: 12, padding: 12, background: 'white' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
          <div style={{ fontWeight: 700, color: '#0f172a' }}>Data Source Fields</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              id="open-fields-btn"
              type="button"
              onClick={() => setIsOpen(v => !v)}
              style={{ padding: '8px 12px', borderRadius: 10, border: '1px solid #e2e8f0', background: '#f8fafc', cursor: 'pointer' }}
            >
              {isOpen ? 'Close' : 'Configure'}
            </button>
            <button
              type="button"
              onClick={saveSettings}
              disabled={!draftSourceIds.some(v => v.trim())}
              style={{
                padding: '8px 12px',
                borderRadius: 10,
                border: '1px solid #0ea5e9',
                background: '#0ea5e9',
                color: 'white',
                cursor: draftSourceIds.some(v => v.trim()) ? 'pointer' : 'not-allowed',
                fontWeight: 600,
              }}
            >
              Save
            </button>
          </div>
        </div>

        {!isOpen ? null : (
          <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {draftSourceIds.map((id, index) => {
              const key = `${index}-${id}`
              return (
                <div key={key} style={{ border: '1px solid #e2e8f0', borderRadius: 12, padding: 12, background: '#ffffff' }}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: '#334155' }}>Source</div>
                    <button
                      type="button"
                      onClick={() => {
                        const next = draftSourceIds.filter((_, i) => i !== index)
                        setDraftSourceIds(next.length ? next : [''])
                      }}
                      style={{ border: '1px solid #e2e8f0', background: '#fff', borderRadius: 10, padding: '6px 10px', cursor: 'pointer' }}
                      aria-label="Remove source"
                    >
                      Remove
                    </button>
                  </div>

                  <input
                    value={id}
                    onChange={e => {
                      const next = draftSourceIds.slice()
                      const prevId = next[index]
                      next[index] = e.target.value
                      setDraftSourceIds(next)
                      if (prevId && prevId !== e.target.value) {
                        setDraftEnabledCsvBySource(prev => {
                          const cloned: Record<string, string> = { ...prev }
                          if (prevId in cloned) {
                            cloned[e.target.value] = cloned[prevId]
                            delete cloned[prevId]
                          }
                          return cloned
                        })
                      }
                    }}
                    placeholder="Layer / table id (e.g. parcels)"
                    style={{ width: '100%', marginTop: 8, padding: '10px 12px', borderRadius: 12, border: '1px solid #e2e8f0' }}
                  />

                  <div style={{ marginTop: 10, fontSize: 12, fontWeight: 700, color: '#334155' }}>Enabled fields (comma separated)</div>
                  <textarea
                    value={draftEnabledCsvBySource[id] ?? ''}
                    onChange={e => setDraftEnabledCsvBySource(prev => ({ ...prev, [id]: e.target.value }))}
                    placeholder="e.g. country, site, project, valve"
                    style={{
                      width: '100%',
                      minHeight: 72,
                      marginTop: 6,
                      padding: '10px 12px',
                      borderRadius: 12,
                      border: '1px solid #e2e8f0',
                      resize: 'vertical',
                      fontFamily: 'inherit',
                    }}
                  />
                </div>
              )
            })}

            <button
              type="button"
              onClick={() => setDraftSourceIds(prev => [...prev, ''])}
              style={{ padding: '10px 12px', borderRadius: 12, border: '1px dashed #94a3b8', background: '#f8fafc', cursor: 'pointer', fontWeight: 600 }}
            >
              Add source
            </button>
          </div>
        )}
      </div>
    )
  }

  const visible = enabledInfo.sourceIds
  const hasAny = visible.some(id => (enabledInfo.enabledBySource[id] ?? []).length > 0)

  if (!hasAny) {
    return (
      <div style={{ padding: 12, borderRadius: 12, border: '1px solid #e2e8f0', background: '#f8fafc', color: '#475569', fontSize: 13 }}>
        No configured data source fields for <span style={{ fontWeight: 700 }}>{formKey}</span>. Ask an Admin/Manager to configure this form in Settings.
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {visible.map(sourceId => {
        const enabledFields = enabledInfo.enabledBySource[sourceId] ?? []
        if (!enabledFields.length) return null
        const sourceValues = valuesBySource[sourceId] ?? {}
        return (
          <div key={sourceId} style={{ border: '1px solid #e2e8f0', borderRadius: 12, background: 'white' }}>
            <div style={{ padding: '12px 14px', borderBottom: '1px solid #e2e8f0', fontWeight: 700, color: '#0f172a' }}>
              {sourceId}
            </div>
            <div style={{ padding: 14, display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
              {enabledFields.map(fieldName => (
                <label key={fieldName} style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12, color: '#334155' }}>
                  <span style={{ fontWeight: 700 }}>{fieldName}</span>
                  <input
                    value={sourceValues[fieldName] ?? ''}
                    onChange={e => {
                      setValuesBySource(prev => {
                        const nextSource = { ...(prev[sourceId] ?? {}) }
                        nextSource[fieldName] = e.target.value
                        const next = { ...prev, [sourceId]: nextSource }
                        const state: DataSourceFormState = {
                          sourceIds: enabledInfo.sourceIds,
                          selectedFieldsBySource: enabledInfo.enabledBySource,
                          valuesBySource: next,
                        }
                        onChange?.(state)
                        return next
                      })
                    }}
                    style={{ padding: '10px 12px', borderRadius: 12, border: '1px solid #e2e8f0' }}
                  />
                </label>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

