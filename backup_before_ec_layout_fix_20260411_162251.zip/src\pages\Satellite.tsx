import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, useMap, GeoJSON, Rectangle, useMapEvents, Polygon } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-draw/dist/leaflet.draw.css';
import 'leaflet-draw';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';
import './satellite/components/PopupStyles.css';
import './Satellite.css';

// Modular Components
import { BasemapGallery, BasemapLayer, BasemapType } from './satellite/components/BasemapGallery';
import { LayerManager, LayerData } from './satellite/components/LayerManager';
import { LayerProperties } from './satellite/components/LayerProperties';
import { MouseCoordinates, ZoomLocationControl, ScaleBar, CustomZoomControl, MiniMap } from './satellite/components/MapControls';
import { SearchWidget } from './satellite/components/SearchWidget';
import { SentinelSearch } from './satellite/components/SentinelSearch';
import { SatelliteStatus, AddDataTool, LegendTool, BookmarksTool, PrintTool, GenericToolPanel } from './satellite/components/ToolPanels';
import { TablePanel } from './satellite/components/TablePanel';
import { UrlInputModal } from './satellite/components/ModalDialog';
import { parseFile } from '../utils/FileLoader';

// Fix for Leaflet default icon issues in React
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

// --- Configuration ---

const LEFT_RAIL_ITEMS = [
  { id: 'satellite_status', icon: 'fa-satellite', title: 'Satellite Status' },
  { id: 'add', icon: 'fa-plus', title: 'Add' },
  { id: 'layers', icon: 'fa-layer-group', title: 'Layers' },
  { id: 'tables', icon: 'fa-table-columns', title: 'Tables' },
  { id: 'basemaps', icon: 'fa-map', title: 'Basemap' },
  { id: 'legend', icon: 'fa-list-check', title: 'Legend' },
  { id: 'bookmarks', icon: 'fa-bookmark', title: 'Bookmarks' },
  { id: 'charts', icon: 'fa-chart-pie', title: 'Charts' },
  { id: 'save', icon: 'fa-floppy-disk', title: 'Save and open' },
  { id: 'properties', icon: 'fa-sliders', title: 'Map properties' },
  { id: 'share', icon: 'fa-share-nodes', title: 'Share map' },
  { id: 'embed', icon: 'fa-code', title: 'Embed map' },
  { id: 'create_app', icon: 'fa-laptop-code', title: 'Create app' },
  { id: 'print', icon: 'fa-print', title: 'Print' },
];

const RIGHT_RAIL_ITEMS = [
  { id: 'item_properties', icon: 'fa-circle-info', title: 'Properties' },
  { id: 'styles', icon: 'fa-paintbrush', title: 'Styles' },
  { id: 'image_explorer', icon: 'fa-images', title: 'Image collection explorer' }, // Sentinel Search here
  { id: 'filter', icon: 'fa-filter', title: 'Filter' },
  { id: 'effects', icon: 'fa-wand-magic-sparkles', title: 'Effects' },
  { id: 'aggregation', icon: 'fa-shapes', title: 'Aggregation' },
  { id: 'popups', icon: 'fa-comment-dots', title: 'Pop-ups' },
  { id: 'fields', icon: 'fa-table', title: 'Fields' },
  { id: 'labels', icon: 'fa-font', title: 'Labels' },
  { id: 'config_charts', icon: 'fa-chart-column', title: 'Configure charts' },
  { id: 'config_editing', icon: 'fa-pen-to-square', title: 'Configure editing' },
  { id: 'map_tools', icon: 'fa-screwdriver-wrench', title: 'Map tools' },
];

  // Helper to capture map instance and events
  const MapRefHandler = ({ mapRef, setZoomLevel }: { mapRef: React.MutableRefObject<L.Map | null>, setZoomLevel: (z: number) => void }) => {
    const map = useMap();
    
    useMapEvents({
      zoomend: () => {
        setZoomLevel(map.getZoom());
      }
    });

    useEffect(() => {
      mapRef.current = map;
      setZoomLevel(map.getZoom());
    }, [map, mapRef, setZoomLevel]);
    return null;
  };

export default function Satellite() {
  const [zoomLevel, setZoomLevel] = useState(13);
  const [layers, setLayers] = useState<LayerData[]>([]);
  const [selectedBasemap, setSelectedBasemap] = useState<BasemapType>('satellite');
  
  // Panel State
  const [activeLeftPanel, setActiveLeftPanel] = useState<string | null>(null);
  const [activeRightPanel, setActiveRightPanel] = useState<string | null>(null); // Default closed
  
  const [hasAOI, setHasAOI] = useState(false);

  // Satellite Intelligence State
  const [activeSpectralIndex, setActiveSpectralIndex] = useState('visual');
  const [showSpectralLayer, setShowSpectralLayer] = useState(true);
  const [selectedDate, setSelectedDate] = useState('2026-02-01');

  // Table Data State
  const [tableData, setTableData] = useState<{ title: string, data: any[] } | null>(null);

  // Layer Properties State
  const [selectedLayerId, setSelectedLayerId] = useState<number | string | null>(null);
  const [selectedAOIId, setSelectedAOIId] = useState<number | string | null>(null);

  // Sentinel Search State
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [selectedTileUrl, setSelectedTileUrl] = useState<string | null>(null);
  
  // Chat State
  const [showChat, setShowChat] = useState(false);
  
  // UI State
  const [isUrlModalOpen, setIsUrlModalOpen] = useState(false);
  const [, setTick] = useState(0);

  // Auto-refresh timer
  useEffect(() => {
     const hasAutoRefresh = layers.some(l => l.autoRefresh);
     if (!hasAutoRefresh) return;

     const interval = setInterval(() => {
        setTick(t => t + 1);
     }, 1000); 

     return () => clearInterval(interval);
  }, [layers]);

  useEffect(() => {
    fetch('/api/aoi')
      .then(res => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        const contentType = res.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
          throw new Error(`Unexpected content type: ${contentType}`);
        }
        return res.json();
      })
      .then(data => {
        if (Array.isArray(data)) {
          const newLayers: LayerData[] = data.map((aoi: any) => ({
            id: aoi.id,
            name: aoi.name || `AOI ${aoi.id}`,
            type: 'geojson',
            visible: true,
            opacity: 0,
            data: { type: 'Feature', geometry: aoi.geometry, properties: { name: aoi.name, id: aoi.id } }
          }));
          
          // Avoid duplicates
          setLayers(prev => {
            const existingIds = new Set(prev.map(l => l.id));
            const uniqueNewLayers = newLayers.filter((l: LayerData) => !existingIds.has(l.id));
            return [...prev, ...uniqueNewLayers];
          });

          if (newLayers.length > 0) {
            setHasAOI(true);
          }
        }
      })
      .catch(err => console.error('Failed to load AOIs:', err));
  }, []);
  
  // --- Helpers ---
  const getInversePolygon = (geoJson: any) => {
    if (!geoJson) return null;
    
    // World coordinates (approximate coverage)
    const world = [
      [90, -180],
      [90, 180],
      [-90, 180],
      [-90, -180]
    ];

    // Extract coordinates from GeoJSON
    // Assuming simple Polygon or MultiPolygon. 
    // For Polygon: coordinates[0] is the outer ring.
    // We need to reverse it to create a hole if we were doing it in one path, 
    // or use MultiPolygon structure: [Outer, Hole]
    
    let holes: any[] = [];

    if (geoJson.geometry.type === 'Polygon') {
        // Leaflet expects [lat, lng], GeoJSON is [lng, lat]
        const ring = geoJson.geometry.coordinates[0].map((c: number[]) => [c[1], c[0]]);
        holes.push(ring);
    } else if (geoJson.geometry.type === 'MultiPolygon') {
        geoJson.geometry.coordinates.forEach((poly: any[]) => {
            const ring = poly[0].map((c: number[]) => [c[1], c[0]]);
            holes.push(ring);
        });
    }

    // Leaflet Polygon can take an array of rings. 
    // First ring is outer, subsequent are holes.
    return [world, ...holes];
  };

  const activeAOILayer = selectedAOIId 
    ? layers.find(l => l.id === selectedAOIId)
    : layers.find(l => l.name.startsWith('AOI') && l.type === 'geojson');
    
  const aoiMaskPositions = hasAOI && activeAOILayer && activeAOILayer.data ? getInversePolygon(activeAOILayer.data) : null;

  const mapRef = useRef<L.Map | null>(null);

  // --- Handlers ---
  
  const onEachFeature = (feature: any, layer: L.Layer) => {
    if (feature.properties) {
      const title = feature.properties.name || feature.properties.Name || feature.properties.id || 'Feature';
      const properties = Object.entries(feature.properties)
        .filter(([key]) => key !== 'name' && key !== 'Name' && key !== 'id')
        .slice(0, 8); // Limit to top 8 properties

      const content = `
        <div class="modern-popup">
          <div class="popup-header">
            <h3 class="popup-title">${title}</h3>
          </div>
          <div class="popup-toolbar">
            <button class="popup-tool-btn" onclick="window.popupActions.table('${title}')">
              <i class="fa-solid fa-table"></i> Table
            </button>
            <button class="popup-tool-btn" onclick="window.popupActions.edit('${title}')">
              <i class="fa-solid fa-pen"></i> Edit
            </button>
            <button class="popup-tool-btn" onclick="window.popupActions.zoom()">
              <i class="fa-solid fa-magnifying-glass-plus"></i> Zoom to
            </button>
          </div>
          <div class="popup-table-container">
            <table class="popup-table">
              <tbody>
                ${properties.map(([key, value]) => `
                  <tr>
                    <td class="popup-key">${key}</td>
                    <td class="popup-value">${value}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          <div class="popup-footer">
            <div class="popup-pagination">
              <button class="popup-page-btn"><i class="fa-solid fa-chevron-left"></i></button>
              <span>1 of 1</span>
              <button class="popup-page-btn"><i class="fa-solid fa-chevron-right"></i></button>
            </div>
            <i class="fa-solid fa-ellipsis" style="color: #999; cursor: pointer;"></i>
          </div>
        </div>
      `;
      layer.bindPopup(content, { maxWidth: 320, minWidth: 300, className: 'modern-popup-wrapper' });
    }
  };

  useEffect(() => {
    // Expose popup actions to window for the HTML strings
    (window as any).popupActions = {
      table: (title: string) => {
        // Logic to open table
        alert(`Show table for ${title}`);
      },
      edit: (title: string) => {
        alert(`Edit ${title}`);
      },
      zoom: () => {
         // This is a bit tricky from static HTML context without passing the layer ID or bounds
         // For now just alert
         alert('Zoom to feature');
      }
    };

    return () => {
      delete (window as any).popupActions;
    };
  }, []);

  const getMapBounds = () => {
    if (!mapRef.current) return null;
    const bounds = mapRef.current.getBounds();
    return [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()];
  };

  const handleSelectImage = (item: any, visualization?: any) => {
    setSelectedItem(item);
    setSelectedTileUrl(null);
  };

  const handleAddLayer = (item: any, visualization?: any) => {
    const collection = item.collection || 'sentinel-2-l2a';
    let layerName = `${collection.toUpperCase()} - ${new Date(item.properties.datetime).toLocaleDateString('en-GB')}`;

    if (visualization) {
       layerName += ` (${visualization.label})`;
    }

    const layerId = visualization ? `${item.id}-${visualization.value}` : item.id;

    setLayers(prev => {
      if (prev.some(l => l.id === layerId)) return prev;
      
      const newLayer: LayerData = {
        id: layerId,
        name: layerName,
        type: 'tile',
        visible: true,
        opacity: 0.8,
        url: '',
        minZoom: 8,
        maxZoom: 20,
        bbox: item.bbox
      };
      return [...prev, newLayer];
    });
    
    setActiveLeftPanel('layers');

    if (item.bbox && mapRef.current) {
      const [minX, minY, maxX, maxY] = item.bbox;
      mapRef.current.fitBounds([[minY, minX], [maxY, maxX]], { padding: [50, 50] });
    }
  };

  // --- Layer Management Handlers ---
  const handleZoomToLayer = (layer: LayerData) => {
    if (!mapRef.current) return;
    
    // For GeoJSON layers
    if (layer.type === 'geojson' && layer.data) {
      try {
        const geoJsonLayer = L.geoJSON(layer.data);
        const bounds = geoJsonLayer.getBounds();
        if (bounds.isValid()) {
          mapRef.current.fitBounds(bounds, { padding: [50, 50] });
        }
      } catch (e) {
        console.error('Error zooming to layer:', e);
      }
    }
    // For Tile layers with bbox
    else if (layer.type === 'tile' && layer.bbox) {
       const [minX, minY, maxX, maxY] = layer.bbox;
       mapRef.current.fitBounds([[minY, minX], [maxY, maxX]], { padding: [50, 50] });
    }
  };

  const handleRemoveLayer = (layerId: number | string) => {
    if (window.confirm('Are you sure you want to remove this layer?')) {
      setLayers(prev => {
        const next = prev.filter(l => l.id !== layerId)
        const hasAnyAOI = next.some(l => typeof l.name === 'string' && l.name.includes('AOI') && l.type === 'geojson')
        setHasAOI(hasAnyAOI)
        return next
      })
    }
  };

  const handleLayerInfo = (layer: LayerData) => {
    setSelectedLayerId(layer.id);
    setActiveRightPanel('item_properties');
    setActiveLeftPanel(null); // Close left panel to focus on properties
  };

  const handleUpdateLayer = (id: number | string, updates: Partial<LayerData>) => {
    setLayers(prev => prev.map(l => l.id === id ? { ...l, ...updates } : l));
  };

  const handleUrlSubmit = (url: string) => {
    // Simulate adding layer
    const name = url.split('/').pop() || 'URL Layer';
    const newLayer: LayerData = {
      id: Date.now(),
      name: name.length > 20 ? name.substring(0, 20) + '...' : name,
      type: 'geojson', // Assume GeoJSON for now or generic 'url' type
      visible: true,
      opacity: 0,
      url: url,
      data: null // No data loaded yet
    };
    setLayers(prev => [...prev, newLayer]);
    
    // Switch to layers panel to show the new layer
    setActiveLeftPanel('layers');
  };

  const handleAddDataAction = (action: string, data?: any) => {
    switch (action) {
      case 'browse':
        // Switch to Sentinel Search or show modal
        setActiveRightPanel('image_explorer');
        break;
      case 'url':
        setIsUrlModalOpen(true);
        break;
      case 'file_loaded':
        if (data && data.file) {
          parseFile(data.file).then((result) => {
            if (result.type === 'geojson') {
              const newLayer: LayerData = {
                id: Date.now(),
                name: result.filename,
                type: 'geojson',
                visible: true,
                opacity: 0,
                data: result.data
              };
              setLayers(prev => [...prev, newLayer]);
              setActiveLeftPanel('layers');
            } else if (result.type === 'table') {
              setTableData({
                title: result.filename,
                data: result.data
              });
              setActiveLeftPanel('tables');
            }
          }).catch(err => {
            console.error("File parsing error:", err);
            alert(`Error parsing file: ${err.message}`);
          });
        }
        break;
      case 'sketch':
        // Open the Sketch/Draw tools panel
        setActiveRightPanel('sketch');
        break;
      case 'media':
        alert('Media layer feature coming soon.');
        break;
    }
  };

  // --- Table Panel Handlers ---
  const handleTableFileSelect = (file: File) => {
    parseFile(file).then((result) => {
      if (result.type === 'table') {
        setTableData({
          title: result.filename,
          data: result.data
        });
      } else if (result.type === 'geojson') {
        // Add to map layers
        setLayers(prev => [...prev, {
          id: Date.now(),
          name: result.filename,
          type: 'geojson',
          visible: true,
          opacity: 0,
          data: result.data
        }]);

        // Also show properties in table
        if (result.data.features && result.data.features.length > 0) {
          const properties = result.data.features.map((f: any) => f.properties);
          setTableData({
            title: result.filename,
            data: properties
          });
        }
      }
    }).catch(err => {
      console.error("File parsing error:", err);
      alert(`Error parsing file: ${err.message}`);
    });
  };

  // Render Content for Panels
  const renderPanelContent = (panelId: string) => {
    const aoiLayer = layers.find(l => l.name.startsWith('AOI') && l.type === 'geojson');
    const aoiGeometry = aoiLayer && aoiLayer.data && (aoiLayer.data as any).geometry ? (aoiLayer.data as any).geometry : null;

    // 1. Specific Components
    switch (panelId) {
      case 'item_properties': {
        const selectedLayer = layers.find(l => l.id === selectedLayerId);
        if (selectedLayer) {
          return (
            <LayerProperties
              layer={selectedLayer}
              onUpdateLayer={handleUpdateLayer}
              onClose={() => setActiveRightPanel(null)}
              currentZoom={zoomLevel}
            />
          );
        }
        return <div style={{ padding: '20px', color: '#666' }}>Select a layer to view properties</div>;
      }

      case 'basemaps':
        return (
          <BasemapGallery 
            selectedBasemap={selectedBasemap} 
            onSelectBasemap={setSelectedBasemap} 
          />
        );
      case 'layers':
        return (
          <LayerManager 
            layers={layers} 
            setLayers={setLayers} 
            onZoomToLayer={handleZoomToLayer}
            onRemoveLayer={handleRemoveLayer}
            onLayerInfo={handleLayerInfo}
          />
        );
      case 'tables':
        return (
          <TablePanel 
            data={tableData?.data || []} 
            title={tableData?.title || 'Tables'} 
            onClose={() => {
              setTableData(null);
              setActiveLeftPanel(null);
            }}
            onAdd={() => setActiveLeftPanel('add')} // Fallback/Legacy
            onFileSelect={handleTableFileSelect}
            onAddFromUrl={() => setIsUrlModalOpen(true)}
          />
        );
      case 'image_explorer':
        return (
          <SentinelSearch 
            onSelectImage={handleSelectImage}
            onAddLayer={handleAddLayer}
            getMapBounds={getMapBounds}
            aoiGeometry={hasAOI && layers.find(l => l.name.startsWith('AOI'))?.data?.geometry}
          />
        );
      case 'satellite_status':
        return <SatelliteStatus />;
      case 'add':
        return <AddDataTool onAction={handleAddDataAction} />;
      case 'legend':
        return <LegendTool layers={layers} />;
      case 'bookmarks':
        return <BookmarksTool />;
      case 'print':
        return <PrintTool />;
    }

    // 2. Generic Fallback for all other items (Left & Right)
    const leftItem = LEFT_RAIL_ITEMS.find(i => i.id === panelId);
    if (leftItem) {
      return (
        <GenericToolPanel 
          title={leftItem.title} 
          icon={leftItem.icon} 
          description={`The ${leftItem.title} tool is currently under development.`}
        />
      );
    }

    const rightItem = RIGHT_RAIL_ITEMS.find(i => i.id === panelId);
    if (rightItem) {
      return (
        <GenericToolPanel 
          title={rightItem.title} 
          icon={rightItem.icon} 
          description={`The ${rightItem.title} tool is currently under development.`}
        />
      );
    }

    // 3. Fallback for unknown IDs
    return <div style={{ padding: '20px', color: '#666' }}>Panel content for {panelId}</div>;
  };

  return (
    <div className="satellite-page">
      <div className="satellite-body">
        {/* Left Navigation Rail */}
      <div className="nav-rail left">
        {LEFT_RAIL_ITEMS.map(item => (
          <div
            key={item.id}
            className={`rail-item ${activeLeftPanel === item.id ? 'active' : ''}`}
            onClick={() => {
              setActiveLeftPanel(activeLeftPanel === item.id ? null : item.id);
              setActiveRightPanel(null); // Close right panel if opening left
            }}
            title={item.title}
          >
            <i className={`fa-solid ${item.icon}`}></i>
          </div>
        ))}
      </div>

      {/* Left Sliding Panel */}
      <div className={`side-panel left ${activeLeftPanel ? 'open' : ''}`}>
        <div className="panel-header">
          <div className="panel-title">{LEFT_RAIL_ITEMS.find(i => i.id === activeLeftPanel)?.title || 'Panel'}</div>
          <button className="panel-close-btn" onClick={() => setActiveLeftPanel(null)} title="Close Panel">
            <i className="fa-solid fa-times"></i>
          </button>
        </div>
        <div className="panel-content">
          {activeLeftPanel && renderPanelContent(activeLeftPanel)}
        </div>
      </div>

      {/* Map Area */}
      <div className="map-wrapper">
        <MapContainer center={[25.2048, 55.2708]} zoom={13} style={{ height: '100%', width: '100%' }} zoomControl={false}>
          {/* Map Logic & Controls */}
          <MapRefHandler mapRef={mapRef} setZoomLevel={setZoomLevel} />
          <BasemapLayer selectedBasemap={selectedBasemap} />
          <MouseCoordinates />
          <SearchWidget />
          <ZoomLocationControl />
          <ScaleBar />
        <CustomZoomControl />
        <MiniMap />
          
          {/* Layer Rendering from LayerManager */}
          {layers.map(layer => {
            if (!layer.visible) return null;
            
            // Check Zoom Levels
            const currentZoom = mapRef.current?.getZoom() || 13; // Default or updated via event ideally
            if (layer.minZoom && currentZoom < layer.minZoom) return null;
            if (layer.maxZoom && currentZoom > layer.maxZoom) return null;

            // GeoJSON Layers
            if (layer.type === 'geojson' && layer.data) {
               // Apply refresh interval if autoRefresh is on (using key to force re-render)
               const key = layer.id + (layer.autoRefresh && layer.refreshInterval ? `_${Math.floor(Date.now() / (layer.refreshInterval || 10000))}` : '');
               
               return (
                <div key={key} className="layer-wrapper">
                  <GeoJSON 
                    data={layer.data} 
                    onEachFeature={onEachFeature}
                    style={{ 
                      color: layer.color || '#3388ff', 
                      weight: layer.weight || 2, 
                      opacity: layer.opacity !== undefined ? layer.opacity : 1, 
                      fillColor: layer.fillColor || layer.color || '#3388ff',
                      fillOpacity: layer.opacity !== undefined ? layer.opacity * 0.2 : 0.2,
                      className: layer.blendMode && layer.blendMode !== 'normal' ? `blend-${layer.blendMode}` : ''
                    }} 
                  />
                </div>
               );
            }

            // Tile Layers
            if (layer.type === 'tile' && layer.url) {
              return (
                <TileLayer
                  key={layer.id}
                  url={layer.url}
                  opacity={layer.opacity !== undefined ? layer.opacity : 1}
                  zIndex={10} // You might want to manage zIndex based on layer order
                  className={layer.blendMode && layer.blendMode !== 'normal' ? `blend-${layer.blendMode}` : ''}
                />
              );
            }
            
            return null;
          })}

          {/* Selected Satellite Imagery */}
          {selectedTileUrl && (
            <TileLayer
              url={selectedTileUrl}
              attribution="Microsoft Planetary Computer"
              zIndex={10}
            />
          )}

          {/* Selected Item Bounding Box */}
          {selectedItem && selectedItem.bbox && (
            <Rectangle 
              bounds={[
                [selectedItem.bbox[1], selectedItem.bbox[0]], 
                [selectedItem.bbox[3], selectedItem.bbox[2]]
              ]}
              pathOptions={{ color: 'orange', fill: false, weight: 2, dashArray: '5, 5' }}
            />
          )}

           {/* AOI Mask Overlay - Visual Clipping */}
           {aoiMaskPositions && selectedItem && (
             <Polygon
               positions={aoiMaskPositions as any}
               pathOptions={{ 
                 color: 'transparent', 
                 fillColor: 'white', 
                 fillOpacity: 0.7,
                 stroke: false
               }}
             />
           )}
 
         </MapContainer>

        {/* AI Assistant Button */}
        <div className={`ai-assistant-fab ${showChat ? 'active' : ''}`} onClick={() => setShowChat(!showChat)}>
          <i className={`fa-solid ${showChat ? 'fa-times' : 'fa-robot'}`}></i>
          <span>{showChat ? 'Close' : 'AgriAI'}</span>
        </div>

        {/* Chat Panel */}
        <div className={`chat-panel ${showChat ? 'open' : ''}`}>
          <div className="chat-header">
            <div className="chat-title">
              <i className="fa-solid fa-robot"></i>
              <span>AgriAI Assistant</span>
            </div>
            <button className="chat-close" onClick={() => setShowChat(false)}>
              <i className="fa-solid fa-times"></i>
            </button>
          </div>
          <div className="chat-content">
            <div className="chat-message system">
              <div className="avatar"><i className="fa-solid fa-robot"></i></div>
              <div className="bubble">
                Hello! I'm your AgriAI assistant. I can help you analyze satellite imagery, interpret indices (NDVI, NDWI), and provide crop health insights.
                <br/><br/>
                Try asking:
                <ul>
                  <li>"What does the low NDVI area indicate?"</li>
                  <li>"Show me the moisture levels for the selected field."</li>
                  <li>"Is there any pest risk based on current weather?"</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="chat-input-area">
            <input type="text" placeholder="Type a message..." />
            <button>
              <i className="fa-solid fa-paper-plane"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Right Sliding Panel */}
      <div className={`side-panel right ${activeRightPanel ? 'open' : ''}`}>
        <div className="panel-header">
          <div className="panel-title">{RIGHT_RAIL_ITEMS.find(i => i.id === activeRightPanel)?.title || 'Panel'}</div>
          <button className="panel-close-btn" onClick={() => setActiveRightPanel(null)} title="Close Panel">
            <i className="fa-solid fa-times"></i>
          </button>
        </div>
        <div className="panel-content">
          {activeRightPanel && renderPanelContent(activeRightPanel)}
        </div>
      </div>

      {/* Right Navigation Rail */}
      <div className="nav-rail right">
        {RIGHT_RAIL_ITEMS.map(item => (
          <div
            key={item.id}
            className={`rail-item ${activeRightPanel === item.id ? 'active' : ''}`}
            onClick={() => {
              setActiveRightPanel(activeRightPanel === item.id ? null : item.id);
              setActiveLeftPanel(null); // Close left panel
            }}
            title={item.title}
          >
            <i className={`fa-solid ${item.icon}`}></i>
          </div>
        ))}
      </div>
      </div>
      {/* Modal Dialogs */}
      <UrlInputModal 
        isOpen={isUrlModalOpen} 
        onClose={() => setIsUrlModalOpen(false)} 
        onSubmit={handleUrlSubmit} 
      />
    </div>
  );
}
