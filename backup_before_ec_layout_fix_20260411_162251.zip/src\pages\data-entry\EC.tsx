import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { DataSourceFieldsPanel, type DataSourceFormState } from './components/datasourcefieldspanel'
import { canManageDataSourceSettings } from '../../lib/auth'
import { ReportModal } from './components/ReportModal'
import './EC.css'

type ECEntry = {
  id: number
  date: string
  time: string
  valve: string
  ecIn: string
  ecOut: string
  phIn: string
  phOut: string
  drainPercent: string
  totalWaterQtyDrip: string
  totalWaterQty: string
  country?: string
  site?: string
  project?: string
  location?: string
}

const STORAGE_KEY = 'ec_records_v1'

const readJson = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

const writeJson = (key: string, value: unknown) => {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
  }
}

export default function EC() {
  const navigate = useNavigate()
  const canManageSettings = useMemo(() => canManageDataSourceSettings(), [])
  const [, setDataSourceState] = useState<DataSourceFormState>({ sourceIds: [], selectedFieldsBySource: {}, valuesBySource: {} })
  const [isOpeningSettings, setIsOpeningSettings] = useState(false)

  const [entries, setEntries] = useState<ECEntry[]>(() => readJson<ECEntry[]>(STORAGE_KEY, []))
  const [isReportOpen, setIsReportOpen] = useState(false)

  const [draft, setDraft] = useState<Omit<ECEntry, 'id'>>({
    date: new Date().toISOString().slice(0, 10),
    time: new Date().toTimeString().slice(0, 5),
    valve: '',
    ecIn: '',
    ecOut: '',
    phIn: '',
    phOut: '',
    drainPercent: '',
    totalWaterQtyDrip: '',
    totalWaterQty: '',
    country: '',
    site: '',
    project: '',
    location: '',
  })

  useEffect(() => {
    writeJson(STORAGE_KEY, entries)
  }, [entries])

  const sorted = useMemo(() => {
    const next = entries.slice()
    next.sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time))
    return next
  }, [entries])

  const canAdd = Boolean(draft.date && draft.time && draft.valve.trim())

  return (
    <div className="ec-page">
      <div className="ec-container ec-animate-in">
        <div className="ec-header">
          <div className="ec-title">
            <i className="fa-solid fa-droplet"></i>
            <div>
              EC / pH
              <div className="ec-section-subtitle">Daily EC / pH and water tracking</div>
            </div>
          </div>
        </div>

        <div className="ec-card">
          <div className="ec-card-header">
            <div>
              <div className="ec-card-title">
                <i className="fa-solid fa-circle-info" style={{ color: 'var(--ec-primary)' }}></i>
                Basic Information
              </div>
              <div className="ec-card-subtitle-small">Configured in Settings (Manager and Admin only)</div>
            </div>
            {canManageSettings ? (
              <div className="ec-card-header-actions">
                <button
                  type="button"
                  className="ec-icon-btn"
                  aria-label="Open data source settings"
                  title="Settings"
                  disabled={isOpeningSettings}
                  onClick={() => {
                    setIsOpeningSettings(true)
                    navigate('/master/workflow-settings?form=EC')
                  }}
                >
                  <i className={isOpeningSettings ? 'fa-solid fa-spinner fa-spin' : 'fa-solid fa-gear'}></i>
                </button>
              </div>
            ) : null}
          </div>
          <div className="ec-card-body">
            <DataSourceFieldsPanel formKey="EC" mode="fill" variant="embedded" onChange={setDataSourceState} />
          </div>
        </div>

        <div className="ec-card">
          <div className="ec-card-header">
            <div className="ec-card-title">
              <i className="fa-solid fa-pen-to-square" style={{ color: '#0ea5e9' }}></i>
              New Reading
            </div>
            <div className="ec-card-header-actions">
              <button type="button" className="ec-btn ec-btn-secondary ec-btn-sm" onClick={() => setIsReportOpen(true)}>
                <i className="fa-solid fa-chart-line"></i> Analytics
              </button>
            </div>
          </div>
          <div className="ec-card-body" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
            <label className="ec-input-group">
              <span className="ec-label">Date</span>
              <input className="ec-input" type="date" value={draft.date} onChange={e => setDraft(prev => ({ ...prev, date: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Time</span>
              <input className="ec-input" type="time" value={draft.time} onChange={e => setDraft(prev => ({ ...prev, time: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Valve</span>
              <input className="ec-input" value={draft.valve} onChange={e => setDraft(prev => ({ ...prev, valve: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Country</span>
              <input className="ec-input" value={draft.country ?? ''} onChange={e => setDraft(prev => ({ ...prev, country: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Site</span>
              <input className="ec-input" value={draft.site ?? ''} onChange={e => setDraft(prev => ({ ...prev, site: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Project</span>
              <input className="ec-input" value={draft.project ?? ''} onChange={e => setDraft(prev => ({ ...prev, project: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Location</span>
              <input className="ec-input" value={draft.location ?? ''} onChange={e => setDraft(prev => ({ ...prev, location: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">EC In</span>
              <input className="ec-input" value={draft.ecIn} onChange={e => setDraft(prev => ({ ...prev, ecIn: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">EC Out</span>
              <input className="ec-input" value={draft.ecOut} onChange={e => setDraft(prev => ({ ...prev, ecOut: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">pH In</span>
              <input className="ec-input" value={draft.phIn} onChange={e => setDraft(prev => ({ ...prev, phIn: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">pH Out</span>
              <input className="ec-input" value={draft.phOut} onChange={e => setDraft(prev => ({ ...prev, phOut: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Drain %</span>
              <input className="ec-input" value={draft.drainPercent} onChange={e => setDraft(prev => ({ ...prev, drainPercent: e.target.value }))} placeholder="e.g. 15%" />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Water (M³)</span>
              <input className="ec-input" value={draft.totalWaterQtyDrip} onChange={e => setDraft(prev => ({ ...prev, totalWaterQtyDrip: e.target.value }))} />
            </label>
            <label className="ec-input-group">
              <span className="ec-label">Water Manual</span>
              <input className="ec-input" value={draft.totalWaterQty} onChange={e => setDraft(prev => ({ ...prev, totalWaterQty: e.target.value }))} />
            </label>
            <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
              <button
                type="button"
                className="ec-btn ec-btn-primary"
                disabled={!canAdd}
                onClick={() => {
                  const next: ECEntry = { id: Date.now(), ...draft }
                  setEntries(prev => [next, ...prev].slice(0, 2000))
                  setDraft(prev => ({ ...prev, valve: '', ecIn: '', ecOut: '', phIn: '', phOut: '', drainPercent: '', totalWaterQtyDrip: '', totalWaterQty: '' }))
                }}
              >
                <i className="fa-solid fa-plus"></i> Add
              </button>
              <button type="button" className="ec-btn ec-btn-ghost" onClick={() => setDraft(prev => ({ ...prev, valve: '' }))}>
                Clear
              </button>
            </div>
          </div>
        </div>

        <div className="ec-card">
          <div className="ec-card-header">
            <div className="ec-card-title">
              <i className="fa-solid fa-list" style={{ color: '#64748b' }}></i>
              Recent Readings
            </div>
          </div>
          <div className="ec-card-body" style={{ overflowX: 'auto' }}>
            {sorted.length === 0 ? (
              <div style={{ color: '#64748b', fontSize: 13 }}>No entries yet.</div>
            ) : (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid #e2e8f0', textAlign: 'left', color: '#64748b' }}>
                    <th style={{ padding: '10px 8px' }}>Date</th>
                    <th style={{ padding: '10px 8px' }}>Valve</th>
                    <th style={{ padding: '10px 8px' }}>EC In</th>
                    <th style={{ padding: '10px 8px' }}>EC Out</th>
                    <th style={{ padding: '10px 8px' }}>pH In</th>
                    <th style={{ padding: '10px 8px' }}>pH Out</th>
                    <th style={{ padding: '10px 8px' }}></th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map(e => (
                    <tr key={e.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                      <td style={{ padding: '10px 8px' }}>
                        {e.date} {e.time}
                      </td>
                      <td style={{ padding: '10px 8px' }}>{e.valve}</td>
                      <td style={{ padding: '10px 8px' }}>{e.ecIn}</td>
                      <td style={{ padding: '10px 8px' }}>{e.ecOut}</td>
                      <td style={{ padding: '10px 8px' }}>{e.phIn}</td>
                      <td style={{ padding: '10px 8px' }}>{e.phOut}</td>
                      <td style={{ padding: '10px 8px' }}>
                        <button type="button" className="ec-btn ec-btn-ghost ec-btn-sm" onClick={() => setEntries(prev => prev.filter(x => x.id !== e.id))}>
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      <ReportModal isOpen={isReportOpen} onClose={() => setIsReportOpen(false)} data={entries} />
    </div>
  )
}
