import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import './Home.css'

interface MenuItem {
  id: string
  label: string
  icon: string
  color: string
  items?: SubMenuItem[]
  to?: string
}

interface SubMenuItem {
  label: string
  icon: string
  to: string
}

const menuItems: MenuItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: 'fa-solid fa-chart-line',
    color: '#F97316',
    items: [
      { label: 'Develop Dashboard', icon: 'fa-solid fa-grip', to: '/dashboard/develop' },
      { label: 'Design & Publish', icon: 'fa-solid fa-palette', to: '/dashboard/design' },
    ]
  },
  {
    id: 'satellite',
    label: 'Satellite Imagery',
    icon: 'fa-solid fa-satellite-dish',
    color: '#8B5CF6', // Violet
    items: [
      { label: 'Satellite Intelligence', icon: 'fa-solid fa-layer-group', to: '/satellite/indices' },
      { label: 'GIS Map', icon: 'fa-solid fa-map-location-dot', to: '/satellite/gis' },
    ]
  },
  {
    id: 'data',
    label: 'Operations',
    icon: 'fa-solid fa-screwdriver-wrench',
    color: '#F59E0B', // Amber
    items: [
      { label: 'Irrigation Scheduling', icon: 'fa-solid fa-water', to: '/data/irrigation' },
      { label: 'Harvest Logging', icon: 'fa-solid fa-tractor', to: '/data/harvest' },
      { label: 'QHIS', icon: 'fa-solid fa-shield-halved', to: '/data/qhis' },
      { label: 'Production Tracking', icon: 'fa-solid fa-boxes-stacked', to: '/data/production' },
    ]
  },
  {
    id: 'sensors',
    label: 'Sensors',
    icon: 'fa-solid fa-microchip',
    color: '#0EA5E9', // Sky
    items: [
      { label: 'Soil Sensors', icon: 'fa-solid fa-seedling', to: '/sensors/soil' },
      { label: 'Weather Sensors', icon: 'fa-solid fa-cloud-sun', to: '/sensors/weather' },
      { label: 'Irrigation Sensors', icon: 'fa-solid fa-faucet-drip', to: '/sensors/irrigation' },
    ]
  },
  {
    id: 'master',
    label: 'Master Data',
    icon: 'fa-solid fa-gear',
    color: '#64748B', // Slate
    items: [
      { label: 'Farm Areas & Crops', icon: 'fa-solid fa-tree', to: '/master/crops' },
      { label: 'Field Types & Names', icon: 'fa-solid fa-tag', to: '/master/fields' },
      { label: 'Valves Configuration', icon: 'fa-solid fa-sliders', to: '/master/valves' },
      { label: 'Recipes', icon: 'fa-solid fa-file-lines', to: '/master/recipes' },
      { label: 'Zones & Sites', icon: 'fa-solid fa-location-dot', to: '/master/zones-sites' },
      { label: 'GIS Content', icon: 'fa-solid fa-layer-group', to: '/master/gis-layer-management' },
    ]
  },
  {
    id: 'admin',
    label: 'Admin',
    icon: 'fa-solid fa-user-shield',
    color: '#1E293B', // Dark
    items: [
      { label: 'User Management', icon: 'fa-solid fa-users', to: '/admin/users' },
    ]
  }
]

export default function Home() {
  const navigate = useNavigate()
  const location = useLocation()
  const [activeGroup, setActiveGroup] = useState<MenuItem | null>(null)

  const getIconKey = (icon: string) => {
    const parts = icon.split(/\s+/).filter(Boolean)
    const specific = parts.find(p => p.startsWith('fa-') && p !== 'fa-solid' && p !== 'fa-regular' && p !== 'fa-brands')
    return (specific || '').replace(/^fa-/, '').replace(/[^a-z0-9-]/gi, '')
  }

  const handleMainClick = (item: MenuItem) => {
    if (item.items) {
      setActiveGroup(item)
    } else if (item.to) {
      navigate(item.to)
    }
  }

  const handleBack = () => {
    setActiveGroup(null)
  }

  useEffect(() => {
    const state = location.state as { openGroup?: string } | null
    if (!state?.openGroup) return
    const group = menuItems.find(i => i.id === state.openGroup && i.items)
    if (group) setActiveGroup(group)
  }, [location.state])

  return (
    <div className="page home-page">
      {activeGroup ? (
        <div className="home-sublist-view fade-in">
          <div className="home-header">
            <button className="back-btn" onClick={handleBack}>
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            <div className="header-title">
              <span 
                className="header-icon" 
                style={{ backgroundColor: activeGroup.color }}
              >
                <i className={activeGroup.icon}></i>
              </span>
              <h2>{activeGroup.label}</h2>
            </div>
          </div>
          
          <div className="sublist-container">
            {activeGroup.items?.map(subItem => (
              <button
                key={subItem.to}
                type="button"
                className="sublist-item"
                onClick={() => navigate(subItem.to)}
                aria-label={subItem.label}
              >
                <div className={`sub-icon-wrapper sub-icon-${getIconKey(subItem.icon)}`}>
                  <i className={subItem.icon}></i>
                </div>
                <span className="sub-label">{subItem.label}</span>
                <i className="fa-solid fa-chevron-right chev-icon"></i>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="home-grid-view fade-in">
          <div className="app-grid">
            {menuItems.map((item) => (
              <div 
                key={item.id} 
                className="app-icon-card" 
                onClick={() => handleMainClick(item)}
              >
                <div 
                  className="icon-circle" 
                  style={{ 
                    background: `linear-gradient(135deg, ${item.color}, ${adjustColor(item.color, -20)})`,
                    boxShadow: `0 4px 15px ${item.color}40`
                  }}
                >
                  <i className={item.icon}></i>
                </div>
                <span className="app-label">{item.label}</span>
                {item.items && <i className="fa-solid fa-chevron-right mini-chev"></i>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// Helper to darken color for gradient
function adjustColor(color: string, amount: number) {
  return '#' + color.replace(/^#/, '').replace(/../g, color => ('0'+Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2));
}
