import express from 'express'
import cors from 'cors'
import { WebSocketServer } from 'ws'
import OpenAI from 'openai'
import { spawn } from 'child_process'
import path from 'path'
import { randomUUID } from 'crypto'
import * as yup from 'yup'

const app = express()
app.use(cors())
app.use(express.json())

app.use(express.static(path.join(process.cwd(), 'dist')))
app.post('/api/tree-detection', (req, res) => {
  const { aoi, apiKey } = req.body
  
  if (!aoi) {
    return res.status(400).json({ error: 'AOI is required' })
  }

  const pythonScript = path.join(process.cwd(), 'server', 'sam_detector.py')
  
  // Use 'python' or 'python3' depending on environment.
  // Assuming 'python' is available in path.
  const pythonProcess = spawn('python', [pythonScript])
  
  let dataString = ''
  let errorString = ''

  pythonProcess.stdout.on('data', (data) => {
    dataString += data.toString()
  })

  pythonProcess.stderr.on('data', (data) => {
    errorString += data.toString()
  })

  pythonProcess.on('close', (code) => {
    if (code !== 0) {
      console.error('Python script error:', errorString)
      return res.status(500).json({ error: 'Tree detection failed', details: errorString })
    }
    
    try {
      const result = JSON.parse(dataString)
      if (result.error) {
        return res.status(500).json(result)
      }
      res.json(result)
    } catch (e) {
      console.error('Failed to parse Python output:', dataString)
      res.status(500).json({ error: 'Invalid response from detection engine', raw: dataString })
    }
  })

  // Send input to Python script
  pythonProcess.stdin.write(JSON.stringify({ aoi, apiKey }))
  pythonProcess.stdin.end()
})

app.post('/api/ai/analyze', (req, res) => {
  const score = Math.round((Math.random() * 0.4 + 0.6) * 100) / 100
  res.json({ score, advisories: ['Irrigate in 24h', 'Apply NPK 10-10-10'] })
})

app.get('/api/weather/latest', (req, res) => {
  res.json({ temp_c: 36.2, humidity_pct: 42, wind_ms: 3.2, rainfall_mm: 0 })
})

// Mock PostGIS Storage
const AOI_STORAGE = []

app.get('/api/aoi', (req, res) => {
  res.json(AOI_STORAGE)
})

app.post('/api/aoi', (req, res) => {
  const aoi = req.body
  if (!aoi || !aoi.geometry) {
    return res.status(400).json({ error: 'Invalid AOI data' })
  }
  // Assign a mock ID if not present
  if (!aoi.id) {
    aoi.id = Date.now()
  }
  AOI_STORAGE.push(aoi)
  console.log('Saved AOI to Mock PostGIS:', aoi.id)
  res.json(aoi)
})

app.delete('/api/aoi/:id', (req, res) => {
  const { id } = req.params
  const index = AOI_STORAGE.findIndex(a => a.id == id)
  if (index !== -1) {
    AOI_STORAGE.splice(index, 1)
    res.json({ success: true })
  } else {
    res.status(404).json({ error: 'AOI not found' })
  }
})

const GEO_LOCATIONS = []
const GEO_ATTRIBUTES = []
const GEO_FORM_LINKS = []

function toInt(value, fallback) {
  const n = Number.parseInt(String(value ?? ''), 10)
  return Number.isFinite(n) ? n : fallback
}

function paginate(items, limit, offset) {
  const safeLimit = Math.max(1, Math.min(100, limit))
  const safeOffset = Math.max(0, offset)
  return {
    total: items.length,
    limit: safeLimit,
    offset: safeOffset,
    items: items.slice(safeOffset, safeOffset + safeLimit),
  }
}

function countVertices(latlngs) {
  if (!latlngs) return 0
  if (Array.isArray(latlngs)) {
    if (latlngs.length === 0) return 0
    if (Array.isArray(latlngs[0])) return countVertices(latlngs[0])
    return latlngs.length
  }
  if (typeof latlngs.lat === 'number' && typeof latlngs.lng === 'number') return 1
  return 0
}

const locationSchema = yup
  .object({
    country: yup.string().required(),
    site: yup.string().trim().required(),
    project: yup.string().required(),
    projectId: yup.string().nullable().default(''),
    zoneId: yup
      .string()
      .transform(v => String(v ?? '').toUpperCase())
      .matches(/^[A-Z0-9]{3}$/)
      .required(),
    codeId: yup
      .string()
      .transform(v => String(v ?? '').toUpperCase())
      .matches(/^[A-Z0-9]{8}$/)
      .required(),
    date: yup.string().required(),
    wkt: yup.string().required(),
    geometryType: yup
      .string()
      .oneOf(['marker', 'polygon', 'polyline', 'circle', 'Point', 'Polygon', 'LineString', 'Circle'])
      .required(),
    latlngs: yup.mixed().required(),
    radius: yup.number().nullable().notRequired(),
    attributes: yup.object().nullable().default(null),
    linkedForms: yup
      .array(
        yup.object({
          id: yup.string().required(),
          permissions: yup.array(yup.string().oneOf(['create', 'read', 'update', 'delete'])).required(),
        })
      )
      .nullable()
      .default([]),
  })
  .noUnknown(true)

app.get('/api/geo/locations', (req, res) => {
  const limit = toInt(req.query.limit, 20)
  const offset = toInt(req.query.offset, 0)
  res.json(paginate(GEO_LOCATIONS, limit, offset))
})

app.post('/api/geo/locations', async (req, res) => {
  try {
    const parsed = await locationSchema.validate(req.body, { abortEarly: false, stripUnknown: true })
    const siteLower = String(parsed.site).toLowerCase()
    const exists = GEO_LOCATIONS.some(l => String(l.site).toLowerCase() === siteLower)
    if (exists) return res.status(409).json({ error: 'Site name must be unique.' })

    const vertexCount = countVertices(parsed.latlngs)
    if (vertexCount > 1000) return res.status(400).json({ error: 'Geometry too complex (>1000 vertices).' })

    const geoId = randomUUID()
    const createdAt = new Date().toISOString()

    const record = {
      id: geoId,
      ...parsed,
      createdAt,
    }
    GEO_LOCATIONS.push(record)

    const attrsSource = parsed.attributes && typeof parsed.attributes === 'object' ? parsed.attributes : {
      country: parsed.country,
      site: parsed.site,
      project: parsed.project,
      projectId: parsed.projectId,
      zoneId: parsed.zoneId,
      codeId: parsed.codeId,
      date: parsed.date,
    }
    for (const [fieldId, value] of Object.entries(attrsSource)) {
      GEO_ATTRIBUTES.push({
        geoId,
        fieldId,
        value,
        tsUtc: createdAt,
      })
    }

    if (Array.isArray(parsed.linkedForms)) {
      for (const link of parsed.linkedForms) {
        GEO_FORM_LINKS.push({
          geoId,
          formId: link.id,
          permissions: link.permissions,
          createdAt,
        })
      }
    }

    res.status(201).json(record)
  } catch (err) {
    if (err?.name === 'ValidationError') {
      return res.status(400).json({ error: 'Validation failed', details: err.errors || [] })
    }
    console.error(err)
    res.status(500).json({ error: 'Internal server error' })
  }
})

app.get('/api/geo/:geoId/forms', (req, res) => {
  const { geoId } = req.params
  const limit = toInt(req.query.limit, 20)
  const offset = toInt(req.query.offset, 0)
  const items = GEO_FORM_LINKS.filter(l => l.geoId === geoId).map(l => ({
    id: l.formId,
    permissions: l.permissions,
    createdAt: l.createdAt,
  }))
  res.json(paginate(items, limit, offset))
})

app.post('/api/geo/:geoId/forms', async (req, res) => {
  const { geoId } = req.params
  const body = req.body || {}

  const schema = yup.object({
    links: yup.array(
      yup.object({
        id: yup.string().required(),
        permissions: yup.array(yup.string().oneOf(['create', 'read', 'update', 'delete'])).required(),
      })
    ).required(),
  }).noUnknown(true)

  try {
    const parsed = await schema.validate(body, { abortEarly: false, stripUnknown: true })
    const exists = GEO_LOCATIONS.some(l => l.id === geoId)
    if (!exists) return res.status(404).json({ error: 'GeoID not found' })

    for (let i = GEO_FORM_LINKS.length - 1; i >= 0; i--) {
      if (GEO_FORM_LINKS[i].geoId === geoId) GEO_FORM_LINKS.splice(i, 1)
    }
    const createdAt = new Date().toISOString()
    for (const link of parsed.links) {
      GEO_FORM_LINKS.push({
        geoId,
        formId: link.id,
        permissions: link.permissions,
        createdAt,
      })
    }
    res.json({ success: true })
  } catch (err) {
    if (err?.name === 'ValidationError') {
      return res.status(400).json({ error: 'Validation failed', details: err.errors || [] })
    }
    console.error(err)
    res.status(500).json({ error: 'Internal server error' })
  }
})

app.get('/api/geo/:geoId/attributes', (req, res) => {
  const { geoId } = req.params
  const attrs = GEO_ATTRIBUTES.filter(a => a.geoId === geoId)
  const asObject = {}
  for (const a of attrs) asObject[a.fieldId] = a.value
  res.json({ geoId, attributes: asObject, items: attrs })
})

const SYSTEM_PROMPT = `
**Role & Objective:**
You are 'AgriCloud', an agricultural science assistant. Answer concisely with a short "Summary" followed by 1–2 brief next steps. Default to English. If the user's message is primarily Arabic or explicitly requests Arabic/translation, respond in Arabic.

**Guidelines:**
1. **Focus:** Prioritize crop physiology, soil science, irrigation, nutrition, plant pathology, entomology, and IPM.
2. **Structure:** Provide variables to monitor (Soil Moisture, EC, pH, Temp, Humidity, VPD), measurement methods, thresholds, and actions.
3. **Evidence:** Use scientifically accepted ranges (e.g., pH 0–14; typical vegetable pH target ~6.0–7.5; caution when soil EC > 4 dS/m).
4. **Safety:** Recommend safe, practical steps and note constraints. Avoid unsafe advice.
5. **Clarity:** Use concise bullets and readable formatting.
`

const VISION_PROMPT = `
**Image Analysis Request - Plant Health Diagnostic**

Please analyze this image as an agricultural expert.

**Focus Areas:**
1.  **Plant Identification:** Identify the crop/plant species if visible.
2.  **Symptom Description:** Detail visible symptoms on leaves, stems, fruits, or roots (e.g., color changes, spots, wilting, deformities).
3.  **Preliminary Assessment:** Suggest the most likely causes (e.g., fungal infection, nutrient deficiency, insect damage, water stress).
4.  **Confidence & Clarity:** Rate your confidence level (Low/Medium/High) and note if the image is unclear.

**Output Format:**
- **Plant:** [Species or "Unidentifiable"]
- **Visible Symptoms:** [Bulleted list]
- **Likely Causes:** [Bulleted list, order by probability]
- **Recommended Next Steps:** [Suggest clear photos to take or key details to provide]
`

// Helper to construct the API Context Prompt
function getApiContextPrompt(userQuestion, extractedSymptoms = "unspecified") {
  return `
The user is asking about: "${userQuestion}".

Before formulating your final answer, you may need to fetch specific data.
If the query is about:
- **Weather/Risk Alerts:** Call the 'getWeatherAlerts' API with the user's provided location (or ask for it).
- **Disease Database:** Call the 'searchDiseaseLibrary' API with the identified symptoms: ${extractedSymptoms}.
- **Product Recommendations:** Call the 'getOrganicRemedies' API with the diagnosed issue.

**API Call Guidance:** Use the functions/APIs available to you. Summarize the fetched data for the user in a helpful, concise way.
`;
}

const OPENAI_API_KEY = process.env.OPENAI_API_KEY
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY

const openai = OPENAI_API_KEY ? new OpenAI({ apiKey: OPENAI_API_KEY }) : null

function chooseLang(en, ar, original) {
  const msg = String(original || '').toLowerCase()
  const hasArabicChars = /[\u0600-\u06FF]/.test(original || '')
  const wantsArabic = hasArabicChars || msg.includes('arabic') || msg.includes('عربي') || msg.includes('بالعربي') || msg.includes('ترجم') || msg.includes('translate')
  return wantsArabic ? ar : en
}

// Data for Simulated AI
const SIM_DATA = {
  tomato: {
    keywords: ['tomato', 'tomatoes', 'lycopersicon'],
    basic: {
      en: "Tomato Care Guide:\n- Temperature: Thrives in 20-30°C.\n- Watering: Regular, deep watering to prevent blossom end rot.\n- Common Issues: Early blight (spots), Hornworms.\n- Tip: Stake plants early to keep fruit off the ground.",
      ar: "دليل العناية بالطماطم:\n- درجة الحرارة: تزدهر بين 20–30°م.\n- الري: ري عميق منتظم لتجنب تعفن الطرف الزهري.\n- مشاكل شائعة: لفحة مبكرة (بقع)، ديدان قرنية.\n- نصيحة: اسند النباتات مبكرًا لإبعاد الثمار عن الأرض."
    },
    detailed: {
      en: "Advanced Tomato Guide:\n- Soil: Well-draining, pH 6.0-6.8. Add compost.\n- Fertilization: Heavy feeder. Use 5-10-10 NPK. Avoid high Nitrogen during fruiting.\n- Pruning: Remove suckers (side shoots) to focus energy on fruit.\n- Diseases: Watch for Septoria Leaf Spot. Rotate crops every 3 years.",
      ar: "دليل الطماطم المتقدم:\n- التربة: جيدة الصرف، pH 6.0-6.8. أضف السماد العضوي.\n- التسميد: نبات نهم. استخدم NPK 5-10-10. تجنب النيتروجين العالي أثناء الإثمار.\n- التقليم: أزل الفروع الجانبية لتركيز الطاقة.\n- الأمراض: راقب تبقع الأوراق السبتوري. دهر المحاصيل كل 3 سنوات."
    }
  },
  cucumber: {
    keywords: ['cucumber', 'cucumbers'],
    basic: {
      en: "Cucumber Care:\n- Watering: Needs consistent moisture. Bitter cucumbers are often caused by heat or water stress.\n- Pests: Watch for Aphids and Cucumber Beetles.\n- Disease: Powdery Mildew is common; improve airflow.",
      ar: "العناية بالخيار:\n- الري: يحتاج إلى رطوبة ثابتة. مرارة الثمار غالبًا سببها الحرارة أو إجهاد الماء.\n- الآفات: راقب المن وخنافس الخيار.\n- الأمراض: البياض الدقيقي شائع؛ حسّن التهوية."
    },
    detailed: {
      en: "Advanced Cucumber Guide:\n- Soil: Fertile, warm soil with pH 6.0-7.0.\n- Trellising: Grow vertically to save space and keep fruit clean.\n- Pollination: Most varieties need bees; if fruit withers, try hand pollination.\n- Harvest: Pick frequently to encourage more production.",
      ar: "دليل الخيار المتقدم:\n- التربة: خصبة ودافئة بـ pH 6.0-7.0.\n- التعريش: ازرع عموديًا لتوفير المساحة ونظافة الثمار.\n- التلقيح: معظم الأصناف تحتاج للنحل؛ إذا ذبلت الثمار، جرب التلقيح اليدوي.\n- الحصاد: اقطف بانتظام لتحفيز الإنتاج."
    }
  },
  date_palm: {
    keywords: ['date', 'palm', 'phoenix', 'dactylifera'],
    basic: {
      en: "Date Palm Management:\n- Irrigation: Critical during fruit development (May-Aug).\n- Pests: Red Palm Weevil is the main threat. Look for bore holes.\n- Harvest: Harvest at the 'Rutab' stage for soft dates.",
      ar: "إدارة نخيل التمر:\n- الري: حاسم خلال تطور الثمار (مايو–أغسطس).\n- الآفات: سوسة النخيل الحمراء هي التهديد الرئيسي؛ ابحث عن ثقوب الساق.\n- الحصاد: احصد في مرحلة الرطب للحصول على تمر طري."
    },
    detailed: {
      en: "Advanced Date Palm Guide:\n- Pollination: Must be done manually in early spring.\n- Thinning: Remove 30% of fruit strands to improve size and quality.\n- Fertilization: Apply NPK + Micronutrients (especially Boron/Zinc) 3 times/year.\n- Disease: Watch for Bayoud disease (fungal wilt).",
      ar: "دليل النخيل المتقدم:\n- التلقيح: يجب أن يتم يدويًا في أوائل الربيع.\n- الخف: أزل 30٪ من الشماريخ لتحسين الحجم والجودة.\n- التسميد: أضف NPK + عناصر صغرى (خاصة البورون/الزنك) 3 مرات سنويًا.\n- الأمراض: راقب مرض البيوض (ذبول فطري)."
    }
  },
  fertilizer: {
    keywords: ['fertilizer', 'npk', 'nutrition', 'nutrient'],
    basic: {
      en: "Fertilizer Advice:\n- Growth Stage: Use high Nitrogen (N).\n- Flowering/Fruiting: Switch to higher Phosphorus (P) and Potassium (K).\n- General: A balanced 10-10-10 NPK is good for maintenance.",
      ar: "نصائح التسميد:\n- مرحلة النمو: استخدم نسبة نيتروجين (N) أعلى.\n- التزهير/الإثمار: انتقل إلى فوسفور (P) وبوتاسيوم (K) أعلى.\n- عام: تركيبة متوازنة 10-10-10 مناسبة للصيانة."
    },
    detailed: {
      en: "Advanced Nutrition:\n- Soil Test: Essential before major applications.\n- Organic: Compost/Manure improves soil structure + nutrients.\n- Deficiency Signs: Yellow leaves (Nitrogen), Purple veins (Phosphorus), Burnt edges (Potassium).",
      ar: "تغذية متقدمة:\n- فحص التربة: ضروري قبل الإضافات الكبيرة.\n- عضوي: الكمبوست/السماد يحسن بنية التربة + العناصر.\n- علامات النقص: أوراق صفراء (نيتروجين)، عروق بنفسجية (فوسفور)، حواف محترقة (بوتاسيوم)."
    }
  },
  irrigation: {
    keywords: ['irrigation', 'water', 'watering'],
    basic: {
      en: "Irrigation Tips:\n- Timing: Water early morning (before 8 AM) to minimize evaporation.\n- Method: Drip irrigation saves 30-50% water compared to sprinklers.\n- Check: Ensure soil is moist at root depth (5-10 cm down).",
      ar: "نصائح الري:\n- التوقيت: اسقِ في الصباح الباكر (قبل 8 صباحًا) لتقليل التبخر.\n- الطريقة: الري بالتنقيط يوفر 30–50٪ من الماء مقارنة بالرش.\n- الفحص: تأكد أن التربة رطبة عند عمق الجذور (5–10 سم)."
    },
    detailed: {
      en: "Advanced Irrigation:\n- ET-Based: Calculate Evapotranspiration (ET0) x Crop Coefficient (Kc).\n- Salinity: If water is saline, apply leaching fraction (extra water) to push salts down.\n- Technology: Use soil moisture sensors for precision.",
      ar: "ري متقدم:\n- معتمد على ET: احسب البخر-النتح (ET0) × معامل المحصول (Kc).\n- الملوحة: إذا كان الماء مالحًا، أضف نسبة غسيل (ماء إضافي) لدفع الأملاح لأسفل.\n- التكنولوجيا: استخدم مجسات رطوبة التربة للدقة."
    }
  },
  pest: {
    keywords: ['pest', 'disease', 'bug', 'worm', 'insect'],
    basic: {
       en: "Integrated Pest Management (IPM):\n- Monitor: Scout weekly for pests.\n- Control: Use biological controls or targeted sprays.\n- Sanitation: Remove infected plant debris.",
       ar: "الإدارة المتكاملة للآفات (IPM):\n- المراقبة: افحص النباتات أسبوعيًا.\n- المكافحة: استخدم مكافحة حيوية أو رش موجه.\n- النظافة: أزل بقايا النباتات المصابة."
    },
    detailed: {
       en: "Advanced IPM Strategy:\n- ID: Correctly identify pest before spraying.\n- Thresholds: Only treat when damage exceeds economic threshold.\n- Rotation: Rotate chemical modes of action to prevent resistance.",
       ar: "استراتيجية IPM متقدمة:\n- التعريف: حدد الآفة بدقة قبل الرش.\n- العتبات: عالج فقط عندما يتجاوز الضرر العتبة الاقتصادية.\n- التدوير: نوّع آليات المبيدات لمنع المقاومة."
    }
  }
}

// Simulated AI Engine with Context
function getSimulatedResponse(message, history = []) {
  const lower = message.toLowerCase()
  
  // 0. Greetings/Identity (Static)
  if (lower.match(/^(hi|hello|hey|greetings)/)) {
    return chooseLang(
      "Hello! I'm AgriCloud, ready to help you with your farming questions.",
      "مرحبًا! أنا أجري كلاود، جاهز لمساعدتك في أسئلة الزراعة.",
      message
    )
  }
  if (lower.includes('who are you') || lower.includes('your name')) {
    return chooseLang(
      "I am AgriCloud, an intelligent assistant designed to help farmers optimize their crops and manage resources.",
      "أنا أجري كلاود، مساعد ذكي لمساعدة المزارعين على تحسين المحاصيل وإدارة الموارد.",
      message
    )
  }
  
  if (lower.includes('help') || lower.includes('what can you do')) {
    return chooseLang(
      "I can analyze plant health from photos, suggest fertilizer plans, provide irrigation schedules, identify common pests, and answer general questions across many topics. Ask me anything.",
      "أستطيع تحليل صحة النبات من الصور، واقتراح خطط تسميد، وتقديم جداول الري، وتحديد الآفات الشائعة، والإجابة عن الأسئلة العامة في مواضيع متعددة. اسألني أي شيء.",
      message
    );
  }

  // 1. Detect Topic & Intent
  const isFollowUp = lower.match(/^(more|detail|continue|what else|again|info)/) || (lower.split(' ').length <= 3 && history.length > 0)
  
  let topicKey = null
  
  // Search current message for keywords
  for (const key in SIM_DATA) {
    if (SIM_DATA[key].keywords.some(k => lower.includes(k))) {
      topicKey = key
      break
    }
  }
  
  // If follow-up, check history
  let isContextual = false
  if (!topicKey && isFollowUp && history.length > 0) {
    // Look back at last user messages
    const recentUserMsgs = history.filter(m => m.role === 'user').slice(-3).reverse()
    for (const msg of recentUserMsgs) {
      const mContent = (msg.content || '').toLowerCase()
      for (const key in SIM_DATA) {
        if (SIM_DATA[key].keywords.some(k => mContent.includes(k))) {
          topicKey = key
          isContextual = true
          break
        }
      }
      if (topicKey) break
    }
  }

  // 2. Generate Response
  if (topicKey) {
    const data = SIM_DATA[topicKey]
    
    // Determine level: Detailed if explicitly asked "more", or if it's a context-based follow-up
    const wantsDetail = lower.includes('detail') || lower.includes('more') || lower.includes('full') || (isContextual && isFollowUp)
    
    // Also give detailed if they repeat the keyword immediately
    const lastUserMsg = history.filter(m => m.role === 'user').pop()
    const immediateRepeat = lastUserMsg && SIM_DATA[topicKey].keywords.some(k => (lastUserMsg.content || '').toLowerCase().includes(k))
    
    if (wantsDetail || immediateRepeat) {
       return chooseLang(data.detailed.en, data.detailed.ar, message)
    }
    return chooseLang(data.basic.en, data.basic.ar, message)
  }
  
  // 3. Fallback / Catch-All
  return chooseLang(
      "Summary: Agronomic approach using measurable variables and thresholds.\nNext Steps: Measure soil moisture, EC, and pH regularly. | Use ET and Kc to plan irrigation.",
      "الملخص: منهج زراعي يعتمد على متغيرات قابلة للقياس وعتبات واضحة.\nالخطوات التالية: قِس رطوبة التربة و EC و pH بانتظام. | استخدم ET و Kc لتخطيط الري.",
      message
  )
}

// Sanitize reply for plain text UI (remove Markdown bold markers)
function formatReply(text) {
  return String(text).replace(/\*\*/g, '')
}

function guessPlant(message) {
  const m = String(message || '').toLowerCase()
  if (m.includes('tomato')) return 'Tomato'
  if (m.includes('cucumber')) return 'Cucumber'
  if (m.includes('date') || m.includes('palm')) return 'Date Palm'
  return 'Unidentified'
}

function getSimulatedVisionResponse(message) {
  const plant = guessPlant(message)
  const en = [
    `Plant: ${plant}`,
    `Location: Provide region (optional)`,
    `Type: Possible insect/disease/abiotic`,
    `Category: Preliminary assessment`,
    `Notes: Capture close, well-lit images of leaves and stems.`,
    `Recommended Actions: Improve airflow; avoid leaf wetness; scout twice weekly.`
  ].join('\n')
  const ar = [
    `النبات: ${plant === 'Unidentified' ? 'غير معروف' : plant}`,
    `الموقع: يرجى ذكر المنطقة (اختياري)`,
    `النوع: حشرة/مرض/إجهاد لا حيوي محتمل`,
    `الفئة: تقييم أولي`,
    `ملاحظات: التقط صورًا قريبة ومضيئة للأوراق والسيقان.`,
    `الإجراءات: حسّن التهوية؛ تجنب البلل الورقي؛ قم بالكشف مرتين أسبوعيًا.`
  ].join('\n')
  return chooseLang(en, ar, message)
}

app.post('/api/ai/chat', async (req, res) => {
  const { message, image, modelProvider = 'openai', history = [] } = req.body
  
  try {
    // Immediate free-mode path
    if (modelProvider === 'simulated') {
      const simReply = image ? getSimulatedVisionResponse(message) : getSimulatedResponse(message, history)
      res.json({ reply: formatReply(simReply), model: 'AgriCloud-Basic (Simulated)' })
      return
    }
    let messages = []
    let targetModel = 'gpt-4o' 

    // Force OpenAI for Vision requests (DeepSeek V3 is text-only usually)
    if (image) {
      if (modelProvider === 'deepseek') {
        console.log("Switching to OpenAI for Vision request")
      }
      
      messages = [
        { role: "system", content: SYSTEM_PROMPT },
        { 
          role: "user", 
          content: [
            { type: "text", text: message ? message + "\n\n" + VISION_PROMPT : VISION_PROMPT },
            { type: "image_url", image_url: { url: image } }
          ]
        }
      ]
    } else {
      // Text Request
      
      // Context Injection (Shared logic)
      const lowerMsg = message.toLowerCase()
      let contextData = ""
      
      if (lowerMsg.includes('weather') || lowerMsg.includes('rain') || lowerMsg.includes('temperature')) {
        contextData = `[System Injection - Mock Weather Data]\nCurrent Conditions: 36.2°C, 42% Humidity. Risk: High Temp.`
      } else if (lowerMsg.includes('pest') || lowerMsg.includes('bug') || lowerMsg.includes('worm')) {
        contextData = `[System Injection - Mock Database]\nFound Organic Remedy: Neem Oil Solution (2%). Application: Evening spray.`
      }

      const finalUserMessage = contextData 
        ? `${message}\n\nCONTEXT_DATA:\n${contextData}\n\nInstruction: Use the provided context data to answer the user's question.` 
        : message

      messages = [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: finalUserMessage }
      ]
    }

    // Use OpenAI SDK
    try {
        if (!openai) {
          throw new Error("OpenAI API key not configured")
        }
        const response = await openai.chat.completions.create({
            model: targetModel,
            messages: messages,
            max_tokens: 1000,
            store: true, 
        });

        const reply = response.choices[0].message.content
        res.json({ reply: formatReply(reply), model: targetModel })

    } catch (openaiError) {
        console.error("OpenAI Error:", openaiError);
        
        let fallbackSuccess = false;

        // 1. Auto-Fallback to DeepSeek for Text Requests
        if (!image && DEEPSEEK_API_KEY) {
            console.log("Falling back to DeepSeek...")
            try {
                // DeepSeek doesn't have an SDK instance here, use fetch
                const deepseekResp = await fetch('https://api.deepseek.com/chat/completions', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${DEEPSEEK_API_KEY}`
                    },
                    body: JSON.stringify({
                      model: 'deepseek-chat',
                      messages: messages,
                      max_tokens: 1000,
                      stream: false
                    })
                })
                
                const deepseekData = await deepseekResp.json()
                if (deepseekResp.ok) {
                    const reply = deepseekData.choices[0].message.content
                    res.json({ reply: formatReply(reply), model: 'deepseek-chat (fallback)' })
                    fallbackSuccess = true;
                    return
                } else {
                    console.error("DeepSeek Fallback Error:", deepseekData)
                }
            } catch (dsError) {
                console.error("DeepSeek Exception:", dsError)
            }
        }
        
        // 2. Final Fallback: Offline/Free Mode (Rule-Based)
        if (!fallbackSuccess) {
            console.log("All APIs failed. Switching to Simulated AI Mode.")
            const simReply = getSimulatedResponse(message, history)
            res.json({ reply: formatReply(simReply), model: 'AgriCloud-Basic (Simulated)' })
            return
        }

        throw openaiError;
    }

  } catch (error) {
    console.error('Chat Error:', error)
    // Fallback to mock response if everything fails
    res.json({ 
      reply: `[System Error] Unable to connect to AI Core (${error.message}).\n\nFallback Advice: Please consult a local expert.` 
    })
  }
})

app.get('*', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'dist', 'index.html'))
})

const server = app.listen(3001, () => {
  console.log('API on http://localhost:3001')
})

const wss = new WebSocketServer({ port: 3002 })
function broadcast(obj) {
  const msg = JSON.stringify(obj)
  wss.clients.forEach(c => { if (c.readyState === 1) c.send(msg) })
}
setInterval(() => {
  broadcast({ topic: 'sensor/ec', payload: (Math.random() * 2 + 1).toFixed(2) })
  broadcast({ topic: 'sensor/ph', payload: (Math.random() * 2 + 6).toFixed(2) })
}, 3000)

process.on('SIGINT', () => {
  server.close(() => process.exit(0))
})
