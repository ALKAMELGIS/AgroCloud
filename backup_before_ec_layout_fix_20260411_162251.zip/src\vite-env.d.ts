/// <reference types="vite/client" />

import type * as React from 'react'

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'calcite-action-group': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        layout?: string
        'overlay-positioning'?: string
        scale?: string
        'selection-mode'?: string
        'calcite-hydrated'?: string
      }
    }
  }
}
