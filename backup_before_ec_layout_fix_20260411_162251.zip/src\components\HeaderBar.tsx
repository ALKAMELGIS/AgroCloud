import './header.css'

export default function HeaderBar() {
  return (
    <header className="agri-header">
      <div className="header-left">
        <span className="logo-icon"><i className="fa-solid fa-leaf"></i></span>
        <span className="logo-text">Agro Cloud</span>
      </div>
      <div className="header-center">
        <img
          className="brand-logo"
          src="https://eliteprojects.ae/wp-content/uploads/2022/07/logo-retraced-white-03.png"
          alt="Elite Agro Projects"
        />
      </div>
      <div className="header-right"></div>
    </header>
  )
}
